#!/usr/bin/env python3
"""
Example 2: Connection Callback Demo
演示连接和断开连接的回调功能
"""

import ubt_robot
import time


def main():
    print("== UbtApi Demo ==")
    
    # 创建 API 实例
    api = ubt_robot.Api()
    
    # 配置连接参数
    config = ubt_robot.Config()
    config.address = "0.0.0.0:51000"  # 指定机器人Api的服务地址
    config.api_id = "demo"               # 填入ApiId
    config.token = ""                     # 填入Token
    
    # 初始化 API
    api.initialize(config)
    
    # 连接成功后触发的回调
    def on_connect():
        print("connect successful")
    
    api.set_connect_callback(on_connect)
    
    # 对端主动断开连接时触发的回调
    def on_disconnect():
        print("peer disconnect")
    
    api.set_disconnect_callback(on_disconnect)
    # 启动 API，内部开始连接机器人服务
    api.start()
    
    # 等待连接完成
    api.wait_until_connected()
    
    # 连接成功后，保持 3 秒钟
    print("Connected, waiting for 3 seconds...")
    time.sleep(3)
    
    # 停止 API 连接服务
    api.stop()
    
    print("== End ==")


if __name__ == "__main__":
    main()
