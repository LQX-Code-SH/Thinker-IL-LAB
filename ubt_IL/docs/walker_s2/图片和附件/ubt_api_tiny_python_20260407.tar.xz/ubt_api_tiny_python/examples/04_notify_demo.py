#!/usr/bin/env python3
"""
Example 4: Notify Demo
演示通知功能，订阅并接收故障变更消息
"""

import ubt_robot
import time


def main():
    print("== UbtApi Demo ==")
    
    # 创建 API 实例
    api = ubt_robot.Api()
    
    # 配置连接参数
    config = ubt_robot.Config()
    config.address = "0.0.0.0:51000"  # 指定机器人Api的服务地址
    config.api_id = "demo"               # 填入ApiId
    config.token = ""                     # 填入Token
    
    # 初始化和启动 API
    api.initialize(config)
    api.start()
    
    # 等待连接完成
    api.wait_until_connected()
    
    # 注册接收故障变更的消息服务
    def on_fault_update(req_id, params):
        print(f"id = {req_id}, result = {params}")
    
    api.add_service("cc.api.fault.current.update", on_fault_update)
    
    # 订阅故障变更消息
    api.notify("cc.api.fault.subscribe")
    
    # 等待 3 秒钟以接收通知
    print("Subscribed to fault updates, waiting for 3 seconds...")
    time.sleep(3)
    
    # 停止 API 连接服务
    api.stop()
    
    print("== End ==")


if __name__ == "__main__":
    main()
