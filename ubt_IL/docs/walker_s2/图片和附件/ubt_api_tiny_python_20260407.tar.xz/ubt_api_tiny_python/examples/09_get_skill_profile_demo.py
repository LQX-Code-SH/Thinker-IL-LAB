#!/usr/bin/env python3
"""
Example 9: Get Skill Profile Demo
演示获取技能详情的功能
"""

import ubt_robot
import time


def main():
    print("== UbtApi Demo ==")
    
    # 创建 API 实例
    api = ubt_robot.Api()
    
    # 配置连接参数
    config = ubt_robot.Config()
    config.address = "0.0.0.0:51000"  # 指定机器人Api的服务地址
    config.api_id = "demo"               # 填入ApiId
    config.token = ""                     # 填入Token
    
    # 初始化和启动 API
    api.initialize(config)
    api.start()
    
    # 等待连接完成
    api.wait_until_connected()
    
    # 准备请求参数
    params = {
        "skillCode": "A000026"
    }
    
    # 获取技能详情
    response = api.request_sync("cc.api.skill.profile", params)
    
    if response.is_success:
        # 如果没有异常，则打印返回内容
        print(f"Success, result: {response.result}")
    else:
        # 如果错误，则打印错误码与错误信息
        print(f"Error, code: {response.error_code}, message: {response.error_message}")
    
    # 等待 3 秒钟
    time.sleep(3)
    
    # 停止 API 连接服务
    api.stop()
    
    print("== End ==")


if __name__ == "__main__":
    main()
