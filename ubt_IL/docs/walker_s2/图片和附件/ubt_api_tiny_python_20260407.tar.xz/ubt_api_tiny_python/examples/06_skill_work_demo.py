#!/usr/bin/env python3
"""
Example 6: Skill Work Demo
演示启动技能任务并等待完成的功能
"""

import ubt_robot


def main():
    print("=== Skill Work API Example ===")
    
    # 创建 API 实例
    api = ubt_robot.Api()
    
    # 配置连接参数
    config = ubt_robot.Config()
    config.api_id = "zhuoshi"
    config.token = ""
    config.address = "0.0.0.0:51000"  # api服务的ip地址
    
    # 初始化和启动 API
    api.initialize(config)
    api.start()
    
    # 等待连接完成
    api.wait_until_connected()
    
    # 创建 Skill 实例
    skill = ubt_robot.Skill(api)
    
    # 准备技能参数
    params = {
        "pitch": 0,
        "yaw": 0
    }
    
    # 启动技能
    work = skill.launch("A000016", params)
    
    if work:
        # 等待技能完成
        result = work.wait_until_finish()
        
        if result.type == ubt_robot.WorkResultType.SUCCESS:
            print(f"Skill finished successfully, result: {result.success_result}")
        elif result.type == ubt_robot.WorkResultType.FAIL:
            print(f"Skill failed, reason: {result.fail_reason}")
        elif result.type == ubt_robot.WorkResultType.STOPPED:
            print("Skill was stopped.")
    else:
        print("Failed to launch skill")
    
    # 停止 API
    api.stop()
    
    print("=== Skill Work API Example End ===")


if __name__ == "__main__":
    main()
