#include <ubt_robot/skill.h>
#include <iostream>
int main()
{
  std::cout << " === Skill Work API Example === " << std::endl;
  ubt::robot::Api ubt_api;

  ubt::robot::Api::Config cfg;
  cfg.api_id = "zhuoshi";
  cfg.token = "";
  cfg.address = "0.0.0.0:51000";  // api服务的ip地址

  ubt_api.initialize(cfg);
  ubt_api.start();
  ubt_api.waitUntilConnected();

  ubt::robot::Skill skill(ubt_api);
  ubt::robot::Skill::Json params;
  params["pitch"] = 0;
  params["yaw"] = 0;
  auto work = skill.launch("A000016", params);
  if (work) {
    work->stop();
    auto result = work->waitUntilFinish();
    if (result.type == ubt::robot::Work::Result::Type::kSuccess) {
      std::cout << "Skill finished successfully, result: " << result.js_succ_result.dump() << std::endl;
    } else if (result.type == ubt::robot::Work::Result::Type::kFail) {
      std::cout << "Skill failed, reason: " << result.js_fail_reason.dump() << std::endl;
    } else if (result.type == ubt::robot::Work::Result::Type::kStoped) {
      std::cout << "Skill was stopped." << std::endl;
    }
  }
  ubt_api.stop();
  std::cout << "=== Skill Work API Example End ===" << std::endl;
  return 0;
}
