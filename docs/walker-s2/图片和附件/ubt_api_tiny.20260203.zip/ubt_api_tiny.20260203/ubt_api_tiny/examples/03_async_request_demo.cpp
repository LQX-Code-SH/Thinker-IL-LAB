#include <iostream>
#include <ubt_robot/api.h>
#include <thread>

using namespace std;
int main()
{
  cout << "== UbtApi Demo ==" << endl;
  ubt::robot::Api ubt_api;

  ubt::robot::Api::Config cfg;
  cfg.address = "0.0.0.0:51000";  //!< 指定机器人Api的服务地址
  cfg.api_id = "demo";    //!< 填入ApiId
  cfg.token = "";         //!< 填入Token

  ubt_api.initialize(cfg);  //!< 初始化

  ubt_api.start();          //!< 启动Api，内部开始连接机器人服务
  ubt_api.waitUntilConnected(); //!< 等待连接完成

  // 异步请求示例(无参数)
  ubt_api.request("cc.api.fault.subscribe",
    [](const ubt::robot::Api::Response &rsp){
    if (rsp.error.code != 0) {
      std::cout << "Subscribe fault error: code = " << rsp.error.code << ", message = " << rsp.error.message << std::endl;
    } else {
      std::cout << "Subscribe fault success: result = " << rsp.js_result.dump() << std::endl;
    }
  });

  // 异步请求示例(带参数)
  ubt::robot::Api::Json js;
  js["startIndex"] = 12;
  js["endIndex"] = 13;
  
  ubt_api.request("cc.api.fault.history.get_range", js,
    [](const ubt::robot::Api::Response &rsp){
    if (rsp.error.code != 0) {
      std::cout << "Get current fault error: code = " << rsp.error.code << ", message = " << rsp.error.message << std::endl;
    } else {
      std::cout << "Get current fault success: result = " << rsp.js_result.dump() << std::endl;
    }
  });
  this_thread::sleep_for(chrono::seconds(3)); //!< 连接成功后，保持3秒钟
  ubt_api.stop(); //!< 停止Api连接服务

  cout << "== End ==" << endl;
  return 0;
}
