#ifndef UBT_ROBOT_API_H_20260120
#define UBT_ROBOT_API_H_20260120

#include <string>
#include <nlohmann/json.hpp>
#include <functional>

namespace ubt::robot {

//! 与机器人 ControlCenter 建立 Api 通信的模块类
class Api {
 public:
  using Json = nlohmann::json;

  //! 初始化配置
  struct Config {
    std::string api_id;       // API身份标识 用于标识请求身份
    std::string token;        // 鉴权令牌 用于身份鉴权
    std::string address;      // 控制中心地址 格式如 "0.0.0.0"
  };

  //! JSONRPC 回复内容
  struct Response {
    Json js_result; //! 结果

    //! 错误相关
    struct {
      int code = 0;         //! 错误码
      std::string message;  //! 错误描述
    } error;
  };

  // 连接和断开(对端断开)回调
  using ConnectCallback = std::function<void()>;
  using DisconnectCallback = std::function<void()>;

  // 服务响应回调
  using ServiceCallback = std::function<void(int req_id, const Json &js_params)>;
  // 请求响应回调
  using RequestCallback = std::function<void(const Response &)>;

 public:
  Api();
  ~Api();

 public:
  bool initialize(const Config &cfg); //! 初始化

  void start();   //! 启动，必须在 initialize() 之后调用
  void stop();    //! 停止

 public:
  //! 设置连接建立的回调
  void setConnectCallback(ConnectCallback &&cb);
  //! 设置连接断开的回调
  void setDisconnectCallback(DisconnectCallback &&cb);
  //! 添加 JSONRPC 服务，并指定回调
  void addService(const std::string &method, ServiceCallback &&cb);
  //! 删除 JSONRPC 服务
  void removeService(const std::string &method);

  //! 异步发送 JSONRPC 带参数的请求，并指定收到回复后的回调
  void request(const std::string &method, const Json &js_params, RequestCallback &&cb);
  //! 异步发送 JSONRPC，并指定收到回复后的回调
  void request(const std::string &method, RequestCallback &&cb);
  //! 异步发送 JSONRPC 带参数的通知
  void notify(const std::string &method, const Json &js_params);
  //! 异步发送 JSONRPC 通知，无参数
  void notify(const std::string &method);

  //! 等待建立连接，等到连接成功或超时返回（阻塞性函数）
  bool waitUntilConnected(std::chrono::milliseconds timeout = std::chrono::milliseconds(0));
  //! 同步发送 JSONRPC 带参数的请求，并等待回复（阻塞性函数）
  Response requestSync(const std::string &method, const Json &js_params);
  //! 同步发送 JSONRPC 请求，并等待回复（阻塞性函数）
  Response requestSync(const std::string &method);

  //! 响应 JSONRPC 请求，发送结果
  void respondResult(int req_id, const Json &js_result);
  //! 响应 JSONRPC 请求，发送错误
  void respondError(int req_id, int errcode, const std::string &message = "");

 private:
  class Impl;
  Impl* impl_;

};
}

#endif // UBT_ROBOT_API_H_20260120
