#ifndef UBT_API_WORK_H
#define UBT_API_WORK_H

#include <string>
#include <functional>
#include <chrono>
#include <future>
#include <nlohmann/json.hpp>

#include <ubt_robot/api.h>

namespace ubt::robot {

//! 任务类，表示一个技能执行的实例
class Work {
 public:
  friend class WorkDispatch;
  friend class Skill;

 public:
  using Id = std::string;  //!< 任务id
  using Json = nlohmann::json;

  enum class State {
    kNone,     //!< 未启动
    kUnderway, //!< 进行中
    kStoped,   //!< 已停止
    kPaused,   //!< 已暂停
    kFinished  //!< 已结束
  };

  struct Result {
    enum class Type {
      kSuccess,  //!< 成功
      kFail,     //!< 失败
      kStoped    //!< 被停止
    };
    Type type;  //! 执行结果类型
    Json js_succ_result;
    Json js_fail_reason;
  };

  using FinishCallback = std::function<void(const Result &)>;

 public:
  ~Work();

 public:
  //! 获取任务ID
  Id getId() const;
  //! 获取任务状态
  State getState() const;
  //! 获取任务结果
  Result getResult() const;
  //! 设置任务状态（仅供内部使用）
  void setState(State state);
  //! 设置任务结束回调
  void setFinishCallback(FinishCallback &&cb);

  //! 暂停任务
  bool pause();
  //! 恢复任务
  bool resume();
  //! 停止任务
  bool stop();

  //! 等待任务结束，或超时返回（阻塞性函数）
  Result waitUntilFinish(std::chrono::milliseconds timeout = std::chrono::milliseconds(0));

 private:
  explicit Work(Api &api, const Id &id);

 private:
  class Impl;
  Impl *impl_;
};

}

#endif // UBT_API_WORK_H
